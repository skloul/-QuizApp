package com.harrywilson.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;

public class QuizActivity extends AppCompatActivity {

    private TextView tvQuestion, tvQuestionNumber;
    private Button btnOption1, btnOption2, btnOption3, btnOption4;
    private ArrayList<QuizQuestion> quizQuestions;
    int currentScore = 0, currentQuestion = 1, currentPos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
        tvQuestion = findViewById(R.id.tvQuestion);
        tvQuestionNumber = findViewById(R.id.tvQuestionAttempted);
        btnOption1 = findViewById(R.id.btnOption1);
        btnOption2 = findViewById(R.id.btnOption2);
        btnOption3 = findViewById(R.id.btnOption3);
        btnOption4 = findViewById(R.id.btnOption4);

        // Setup Quiz Questions
        quizQuestions = new ArrayList<>();
        getQuizQuestions(quizQuestions);

        // Update on screen TextViews
        updateTextViews(currentPos);

        // Check for options buttons that have been clicked
        optionClicked(btnOption1);
        optionClicked(btnOption2);
        optionClicked(btnOption3);
        optionClicked(btnOption4);
    }

    // Add quiz questions to array
    private void getQuizQuestions(ArrayList<QuizQuestion> quizQuestions) {
        quizQuestions.add(new QuizQuestion("What is my name?", "Harry", "Barry", "Larry", "Parry", "Harry"));
        quizQuestions.add(new QuizQuestion("What is my age?", "18", "19", "20", "21", "20"));
        quizQuestions.add(new QuizQuestion("Where do I live?", "England", "Scotland", "Wales", "France", "Scotland"));
        quizQuestions.add(new QuizQuestion("What is my favorite food?", "Pizza", "Pork", "Chicken", "Pasta", "Chicken"));
    }

    // Update TextView's to display correct question
    private void updateTextViews(int CurrentPos){
        tvQuestionNumber.setText("Question: " + currentQuestion + "/" + quizQuestions.size());
        tvQuestion.setText(quizQuestions.get(CurrentPos).getQuestion());
        btnOption1.setText(quizQuestions.get(CurrentPos).getOption1());
        btnOption2.setText(quizQuestions.get(CurrentPos).getOption2());
        btnOption3.setText(quizQuestions.get(CurrentPos).getOption3());
        btnOption4.setText(quizQuestions.get(CurrentPos).getOption4());
    }

    // Check for option buttons that have been clicked
    private void optionClicked(Button button){
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Check if the clicked option is correct
                if(quizQuestions.get(currentPos).getAnswer().trim().toLowerCase().equals(button.getText().toString().trim().toLowerCase())){
                    currentScore++;
                }
                if (currentQuestion < quizQuestions.size()) {
                    // More questions available, update question and TextView's
                    currentQuestion++;
                    currentPos++;
                    updateTextViews(currentPos);
                }
                else {
                    // Quiz Complete, Submit results and show score
                    submitScore();
                    showResults();
                }

            }
        });
    }

    // Submit users score to Firebase DB
    public void submitScore() {
        // Create new UseResult Data Access Object
        UserResultDAO userResultDAO = new UserResultDAO();

        // Get logged in user's email
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        String email = mAuth.getCurrentUser().getEmail();

        //Create new userResult with email and score
        UserResult userResult = new UserResult(email, currentScore);

        // Add userResult to DB
        userResultDAO.add(userResult);
    }

    // Display results on screen
    private void showResults(){
        // Display bottom sheet dialog
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(QuizActivity.this);
        View bottomSheetView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.score_sheet,(LinearLayout)findViewById(R.id.llScore));
        TextView tvScore = bottomSheetView.findViewById(R.id.tvScore);
        tvScore.setText("Your score is\n" + currentScore + "/" + quizQuestions.size());
        bottomSheetDialog.setCancelable(false);
        bottomSheetDialog.setContentView(bottomSheetView);
        bottomSheetDialog.show();

        // Register Click on Home Button
        Button btnHome = bottomSheetView.findViewById(R.id.btnHome);
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Close results menu and return home
                bottomSheetDialog.dismiss();
                startActivity(new Intent(QuizActivity.this, HomeActivity.class));
            }
        });
    }


}