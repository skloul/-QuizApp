package com.harrywilson.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class HomeActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private Button btnStart;
    private Button btnLogout;
    private Button btnTopScores;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        mAuth = FirebaseAuth.getInstance();
        btnLogout = findViewById(R.id.btnlogout);
        btnStart = findViewById(R.id.btnStart);
        btnTopScores = findViewById(R.id.btnTopScores);

        // Register Click on Start Quiz Button
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { startActivity(new Intent(HomeActivity.this, QuizActivity.class)); }
        });

        // Register Click on Top Scores Button
        btnTopScores.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { startActivity(new Intent(HomeActivity.this, ScoreBoardActivity.class)); }
        });

        // Register Click on Logout Button
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { logout(); }
        });
    }
    @Override
    public void onStart(){
        super.onStart();
        // Get logged in user
        FirebaseUser currentUser = mAuth.getCurrentUser();

        // If there is no logged in user open login page
        if(currentUser==null){
            startActivity(new Intent(HomeActivity.this, LoginActivity.class));
        }
    }

    // Logout of Authentication and open login page
    public void logout(){
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(HomeActivity.this, LoginActivity.class));
    }
}