package com.harrywilson.quizapp;

public class UserResult {
    private String email;
    private int score;

    public UserResult(String email, int score) {
        this.email = email;
        this.score = score;
    }

    public String getEmail() {
        return email;
    }

    public int getScore() {
        return score;
    }
}

