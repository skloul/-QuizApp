package com.harrywilson.quizapp;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.List;

public class UserResultDAO {

    private DatabaseReference databaseReference;
    public UserResultDAO() {
        // Get Database reference
        FirebaseDatabase db = FirebaseDatabase.getInstance("https://quiz-app-f92cd-default-rtdb.europe-west1.firebasedatabase.app");
        databaseReference = db.getReference(UserResult.class.getSimpleName());
    }

    // Add UserResult to DB
    public Task<Void> add(UserResult userResult) {
        return databaseReference.push().setValue(userResult);
    }

    // Return DB - Incomplete
    public Task<Void> returnScores() {
        List<UserResult> userResults = null;
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // Loop through DB Data
                for (DataSnapshot record : snapshot.getChildren()) {

                    // Get email and score
                    String email = record.child("email").getValue().toString();
                    Long longScore = (Long) record.child("score").getValue();
                    int score = 0;
                    score = longScore.intValue();

                    // Add data to List
                    if (email != null){
                        UserResult userData = new UserResult(email, score);
                        System.out.println(userData.getScore());
                        userResults.add(userData);
                    }

                }
                // Print data in list
                if (userResults != null) {
                    for (UserResult uR : userResults){
                        System.out.println(uR.getEmail() + " " + uR.getScore());
                    }
                }
            }
            // Error in returning DB
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                System.out.println("Error: " + error.getMessage());
            }
        });
        return null;
    }
}
