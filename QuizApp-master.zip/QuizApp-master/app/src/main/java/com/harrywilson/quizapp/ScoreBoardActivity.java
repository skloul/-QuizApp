package com.harrywilson.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ScoreBoardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score_board);
        Button btnHome = findViewById(R.id.btnHome);

        // Create new UseResult Data Access Object
        UserResultDAO userResultDAO = new UserResultDAO();

        // Return user scores from DB
        userResultDAO.returnScores();

        // Register Click on Home Button
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { startActivity(new Intent(ScoreBoardActivity.this, HomeActivity.class));;}
        });
    }
}